/**
 * Created by sailengsi on 2017/5/10.
 */

import {gbs,cbs} from './settings';


export {
	gbs,
	cbs,
    // baseUrl,  //后面会去掉
	// routerMode,
    // baseImgPath
};