
import * as mUtils from '@/utils/mUtils'


const types = {
    ADD_MENU : 'ADD_MENU', //
    LOAD_ROUTES : 'LOAD_ROUTES'   //
}

const state = {
	userinfo: mUtils.getStore('userinfo') || {},
}

const getters = {

}

const mutations = {
  
}

const actions = {
  
}

export default {
    state,
    getters,
    mutations,
    actions
}